from sppd import sppd

def main():
    sppd

if __name__ == "__main__":
    main()

