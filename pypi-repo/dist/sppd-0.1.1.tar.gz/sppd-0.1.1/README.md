# sppd - spotify playlist downloader
## Windows
```
py -m sppd [PLAYLIST]
```
## Anything else
```
python3 -m sppd [PLAYLIST]
```
