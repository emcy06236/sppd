# sppd - spotify playlist downloader
## Windows
```
sppd [PLAYLIST]
```
## Anything else
```
python3 -m sppd [PLAYLIST]
```
